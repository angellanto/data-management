-- Count rows in the Invoice table
SELECT 'Invoice' AS TableName, COUNT(*) AS RowCount FROM invoice;

-- Count rows in the Customer table
SELECT 'Customer' AS TableName, COUNT(*) AS RowCount FROM customer;

-- Count rows in the Sales table
SELECT 'Sales' AS TableName, COUNT(*) AS RowCount FROM sales;

-- Count rows in the Product table
SELECT 'Product' AS TableName, COUNT(*) AS RowCount FROM product;


-- Identify null rows for all tables 
SELECT  
    'Invoice' AS TableName, 
    SUM(CASE WHEN InvoiceNo IS NULL THEN 1 ELSE 0 END) AS InvoiceNo_Missing, 
    SUM(CASE WHEN InvoiceDate IS NULL THEN 1 ELSE 0 END) AS InvoiceDate_Missing,  
    SUM(CASE WHEN CustomerID IS NULL THEN 1 ELSE 0 END) AS CustomerID_Missing
FROM invoice; 

SELECT  
    'Customer' AS TableName, 
    SUM(CASE WHEN CustomerID IS NULL THEN 1 ELSE 0 END) AS CustomerID_Missing, 
    SUM(CASE WHEN Country IS NULL THEN 1 ELSE 0 END) AS Country_Missing
FROM customer; 

SELECT  
    'Sales' AS TableName, 
    SUM(CASE WHEN InvoiceNo IS NULL THEN 1 ELSE 0 END) AS InvoiceNo_Missing, 
    SUM(CASE WHEN StockCode IS NULL THEN 1 ELSE 0 END) AS StockCode_Missing, 
    SUM(CASE WHEN Quantity IS NULL THEN 1 ELSE 0 END) AS Quantity_Missing
FROM sales; 

SELECT  
    'Product' AS TableName, 
    SUM(CASE WHEN StockCode IS NULL THEN 1 ELSE 0 END) AS StockCode_Missing, 
    SUM(CASE WHEN Description IS NULL THEN 1 ELSE 0 END) AS Description_Missing, 
    SUM(CASE WHEN UnitPrice IS NULL THEN 1 ELSE 0 END) AS UnitPrice_Missing
FROM product; 

-- Identify customers who make frequent purchases 
SELECT 
    c.CustomerID, 
    COUNT(s.InvoiceNo) AS purchase_frequency, 
    SUM(s.Quantity) AS total_purchases
FROM customer c
INNER JOIN invoice i ON c.CustomerID = i.CustomerID
LEFT JOIN sales s ON i.InvoiceNo = s.InvoiceNo
GROUP BY c.CustomerID
ORDER BY purchase_frequency DESC
LIMIT 5; 

-- Identify which customers have made the most and least transactions  
SELECT 
    i.CustomerID, 
    COUNT(s.InvoiceNo) AS most_transactions
FROM invoice i
INNER JOIN sales s ON i.InvoiceNo = s.InvoiceNo 
GROUP BY i.CustomerID
ORDER BY most_transactions DESC
LIMIT 1; 

SELECT 
    i.CustomerID, 
    COUNT(s.InvoiceNo) AS least_transactions
FROM invoice i
INNER JOIN sales s ON i.InvoiceNo = s.InvoiceNo 
GROUP BY i.CustomerID
ORDER BY least_transactions ASC
LIMIT 1;  

-- Identify customers with the lowest and highest number of transactions  
SELECT 
    i.CustomerID, 
    COUNT(s.InvoiceNo) AS lowest_transactions
FROM invoice i
INNER JOIN sales s ON i.InvoiceNo = s.InvoiceNo 
GROUP BY i.CustomerID
ORDER BY lowest_transactions ASC
LIMIT 5; 

SELECT 
    i.CustomerID, 
    COUNT(s.InvoiceNo) AS highest_transactions
FROM invoice i
INNER JOIN sales s ON i.InvoiceNo = s.InvoiceNo 
GROUP BY i.CustomerID
ORDER BY highest_transactions DESC
LIMIT 5; 

-- Understand which customers are buying specific products and in what quantity  
SELECT 
    c.CustomerID, 
    p.StockCode, 
    p.Description, 
    SUM(s.Quantity) AS total_purchases
FROM customer c
INNER JOIN invoice i ON c.CustomerID = i.CustomerID
LEFT JOIN sales s ON i.InvoiceNo = s.InvoiceNo
LEFT JOIN product p ON s.StockCode = p.StockCode
GROUP BY c.CustomerID, p.StockCode
HAVING p.StockCode IS NOT NULL
ORDER BY total_purchases DESC;  

-- Identify products that are trending based on purchase frequency  
SELECT 
    s.StockCode, 
    p.Description, 
    COUNT(s.InvoiceNo) AS purchase_frequency, 
    SUM(s.Quantity) AS total_purchases
FROM sales s
INNER JOIN product p ON s.StockCode = p.StockCode
GROUP BY s.StockCode
ORDER BY purchase_frequency DESC; 

-- Identify products that are trending based on the total purchases  
SELECT 
    s.StockCode, 
    p.Description, 
    SUM(s.Quantity) AS total_quantity_sold,
    SUM(s.Quantity * p.UnitPrice) AS total_amount_of_sales
FROM sales s
INNER JOIN product p ON s.StockCode = p.StockCode
GROUP BY s.StockCode, p.Description
ORDER BY total_quantity_sold DESC;

-- Identify products with highest sales
SELECT 
    s.StockCode, 
    p.Description, 
    SUM(s.Quantity) AS total_quantity_sold,
    SUM(s.Quantity * p.UnitPrice) AS total_amount_of_sales
FROM sales s
INNER JOIN product p ON s.StockCode = p.StockCode
GROUP BY s.StockCode, p.Description
ORDER BY total_amount_of_sales DESC;

-- Track product purchasing trends over time to identify seasonal or emerging trends  
SELECT 
    i.InvoiceDate, 
    s.StockCode, 
    SUM(s.Quantity) AS total_purchases
FROM sales s 
INNER JOIN invoice i ON i.InvoiceNo = s.InvoiceNo
GROUP BY i.InvoiceDate, s.StockCode
ORDER BY i.InvoiceDate, total_purchases DESC; 

-- Segment customers based on total spending  
SELECT 
    cs.CustomerID,
    cs.total_quantity,
    cs.total_spent, 
    CASE
        WHEN cs.total_spent >= 1000 THEN 'High Spender'
        WHEN cs.total_spent BETWEEN 500 AND 999 THEN 'Medium Spender'
        ELSE 'Low Spender'
    END AS spending_segment
FROM ( 
    SELECT 
        c.CustomerID, 
        SUM(s.Quantity) AS total_quantity, 
        SUM(s.Quantity * p.UnitPrice) AS total_spent
    FROM customer c
    INNER JOIN invoice i ON c.CustomerID = i.CustomerID
    LEFT JOIN sales s ON i.InvoiceNo = s.InvoiceNo
    LEFT JOIN product p ON s.StockCode = p.StockCode
    GROUP BY c.CustomerID
) AS cs
ORDER BY cs.total_spent DESC; 

-- Identify which countries are making the most purchases  
SELECT 
    c.Country, 
    SUM(s.Quantity) AS total_purchases,
    SUM(s.Quantity * p.UnitPrice) AS total_amount_of_sales
FROM customer c
INNER JOIN invoice i ON c.CustomerID = i.CustomerID
INNER JOIN sales s ON i.InvoiceNo = s.InvoiceNo
LEFT JOIN product p ON s.StockCode = p.StockCode
GROUP BY c.Country
ORDER BY total_purchases DESC
LIMIT 5;

-- Most purchased products in UK
SELECT 
	c.Country, 
    s.StockCode, 
    p.Description, 
    SUM(s.Quantity) AS total_quantity_sold,
    SUM(s.Quantity * p.UnitPrice) AS total_amount_of_sales
FROM sales s
INNER JOIN product p ON s.StockCode = p.StockCode
LEFT JOIN invoice i ON s.InvoiceNo = i.InvoiceNo 
LEFT JOIN customer c ON i.CustomerID = c.CustomerID 
WHERE c.Country = 'United Kingdom'
GROUP BY s.StockCode, p.Description
ORDER BY total_quantity_sold DESC;

