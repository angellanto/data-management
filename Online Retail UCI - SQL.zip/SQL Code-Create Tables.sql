-- Create the Customer Table
CREATE TABLE Customer (
    CustomerID VARCHAR(20) PRIMARY KEY,
    Country VARCHAR(100)
);

-- Create the Product Table
CREATE TABLE Product (
    StockCode VARCHAR(20) PRIMARY KEY,
    Description VARCHAR(255),
    UnitPrice DECIMAL(10, 2)
);

-- Create the Invoice Table
CREATE TABLE Invoice (
    InvoiceNo VARCHAR(20) PRIMARY KEY,
    InvoiceDate DATE,
    CustomerID VARCHAR(20),
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
);

-- Create the Sales Table
CREATE TABLE Sales (
    InvoiceNo VARCHAR(20),
    StockCode VARCHAR(20),
    Quantity INT,
    PRIMARY KEY (InvoiceNo, StockCode),
    FOREIGN KEY (InvoiceNo) REFERENCES Invoice(InvoiceNo),
    FOREIGN KEY (StockCode) REFERENCES Product(StockCode)
);